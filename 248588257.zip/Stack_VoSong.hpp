#ifndef STACK_VOSONG_HPP
#define STACK_VOSONG_HPP

#include <iostream>
#include <stdexcept>

template<typename T>
class Stack {
private:
    struct Node {
        T data;
        Node* next;
        Node(const T& data) : data(data), next(nullptr) {}
    };

    Node* topPtr;
    size_t size;

public:
    Stack() : topPtr(nullptr), size(0) {}

    ~Stack() {
        while (!isEmpty())
            pop();
    }

    void push(const T& data) {
        Node* newNode = new Node(data);
        newNode->next = topPtr;
        topPtr = newNode;
        size++;
    }

    void pop() {
        if (isEmpty())
            throw std::runtime_error("Stack is empty");
        Node* temp = topPtr;
        topPtr = topPtr->next;
        delete temp;
        size--;
    }

    T& top() const {
        if (isEmpty())
            throw std::runtime_error("Stack is empty");
        return topPtr->data;
    }

    bool isEmpty() const {
        return size == 0;
    }

    size_t getSize() const {
        return size;
    }
};

#endif // STACK_VOSONG_HPP
