/*
File: MatrixGraph_<vosong>.h
Description: Contains the declarations for the MatrixGraph class.

Topics:
- Use object-oriented C++ to build a graph data structure using an adjacency matrix
- Traverse the graph and find paths between nodes using BFS
- Use C++’s built-in file IO to read graph data into your graph using the specified format
- Read and parse command line arguments to modify program behavior

Outcomes:
- Identify, construct, and clearly define a data structure that is useful for modeling a given problem.
- State some fundamental algorithms such as merge sort, topological sort, prim's and Kruskal’s algorithm, and algorithmic techniques such as dynamic programming and greedy algorithms
- Combine fundamental data structures and algorithmic techniques in building a complete algorithmic solution to a given problem
- Design an algorithm to solve a given problem

Description:
This project builds undirected and directed weighted graphs using an adjacency matrix and searches them with breadth first search (BFS).

Specifications:
Classes and Structure:
Queue: You will be using a queue for your implementation of breadth first search.
MatrixGraph: Your graph class should have a simple Interface.

Method Description:
- MatrixGraph(int, bool): Constructor builds matrix with a number of vertexes and true if directed
- addEdge(int, int):void Adds an edge between two vertices
- addEdge(int, int, float):void Adds an edge with a weight
- removeEdge(int, int):void Removes an edge between two vertices
- adjacent(int, int):bool Returns whether two vertices have an edge between them
- getEdgeWeight(int, int):float Returns the weight of an edge, throws exception if edge doesn’t exist
- setEdgeWeight(int, int, float):void Changes an edge weight
- toString():std::string Returns a string representation of the graph for easy output
- printRaw():void Prints the 2D Array to standard output (primarily for debugging)
- pathExists(int, int):bool Returns if a path exists between two vertices
- getBFSPath(int, int):std::vector<int> Returns a vector of vertex numbers that shows the path between two vertices in order from start to goal.

This is the only place you can use standard library containers.

Your MatrixGraph class should maintain a 2D array representation of the Adjacency Matrix.

Implementing Your graph
Matrix Data Structure:
Empty Spots: Empty spots should be represented with a 0.

Reading a Graph from a File/Command Line:
Command line spec:
<exe> {-u|-w} <file> [-ud]

File Structure:
The file will be structured as follows:
- Line 1: <number of vertices> <number of edges>
- Subsequent lines:
  - Weighted: <v1> <v2> <weight> (int, int, float)
  - Unweighted: <v1> <v2> (int, int)
*/

#ifndef MATRIXGRAPH_H
#define MATRIXGRAPH_H

#include <vector>
#include <string>

class MatrixGraph {
private:
    int numVertices;
    float** adjacencyMatrix;
    bool directed;
    bool isWeight;

public:
    // Constructor
    MatrixGraph(int numVertices, bool directed);
    ~MatrixGraph();
    // Method declarations
    int getNumVertices() const {
        return numVertices;
    }
    void addEdge(int v1, int v2);
    void addEdge(int v1, int v2, float weight);
    void removeEdge(int v1, int v2);
    bool adjacent(int v1, int v2);
    float getEdgeWeight(int v1, int v2);
    void setEdgeWeight(int v1, int v2, float weight);
    std::string toString() const;
    void printRaw();
    bool pathExists(int start, int goal);
    std::vector<int> getBFSPath(int start, int goal);
    void setIsWeight(bool isWeight);
    bool getIsWeight();
    std::vector<int> getDijkstraPath(int start, int goal);
    std::vector<int>* getDijkstraAll(int start);
    void printPrimMST();
};

#endif // MATRIXGRAPH_H
