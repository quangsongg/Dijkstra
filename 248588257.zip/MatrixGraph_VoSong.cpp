/*
Author: Song Vo
Date : 04/18/24
 Description : ...
 */
#include <fstream>
#include <iostream>
#include <sstream>
#include "Queue_VoSong.hpp"
#include "MatrixGraph_VoSong.h"
#include "minmaxheap_VoSong.hpp"
#include <algorithm>
#include <iomanip>
using namespace std;

const int MAX_INT_D = 1e9;


struct Pair {
    int weight;
    int node;

    bool operator>(const Pair& other) {
        if(weight == other.weight) {
            return node > other.node;
        }
        return weight > other.weight;
    }

    bool operator<(const Pair& other) {
        if(weight == other.weight) {
            return node < other.node;
        }
        return weight < other.weight;
    }
};



MatrixGraph::MatrixGraph(int numVertices, bool directed) : numVertices(numVertices), directed(directed) {
    this->isWeight = true;
    adjacencyMatrix = new float* [numVertices + 1];
    for (int i = 0; i <= numVertices; ++i) {
        adjacencyMatrix[i] = new float[numVertices + 1]();
    }
    for (int i = 0; i <= numVertices; ++i) {
        for (int j = 0; j <= numVertices; ++j) {
            adjacencyMatrix[i][j] = 0.0f;
        }
    }
}

MatrixGraph::~MatrixGraph() {
    for (int i = 0; i <= numVertices; ++i) {
        delete[] adjacencyMatrix[i];
    }
    delete[] adjacencyMatrix;
}

void MatrixGraph::setIsWeight(bool isWeight) {
    this->isWeight = isWeight;
}
bool MatrixGraph::getIsWeight() {
    return this->isWeight;
}

    void MatrixGraph::addEdge(int v1, int v2) {
        addEdge(v1, v2, -1); // Default weight is 1 for unweighted edges
    }

    void MatrixGraph::addEdge(int v1, int v2, float weight) {
        if (v1 >= 0 && v1 <=  numVertices && v2 >= 0 && v2 <=  numVertices) {
             adjacencyMatrix[v1][v2] = weight;
            if (!directed)
                adjacencyMatrix[v2][v1] = weight; // For undirected graph, add the reverse edge
        } else {
            cout << "Invalid vertices.\n" << v1 << " " << v2 << endl;;
        }
    }

    void MatrixGraph::removeEdge(int v1, int v2) {
        if (v1 >= 0 && v1 <= numVertices && v2 >= 0 && v2 <= numVertices) {
             adjacencyMatrix[v1][v2] = 0;
            if (!directed)
                adjacencyMatrix[v2][v1] = 0; // Remove reverse edge for undirected graph
        } else {
            cout << "Invalid vertices.\n";
        }
    }

    bool MatrixGraph::adjacent(int v1, int v2) {
        if (v1 >= 0 && v1 <= numVertices && v2 >= 0 && v2 <= numVertices) {
            return adjacencyMatrix[v1][v2] != 0;
        } else {
            cout << "Invalid vertices.\n";
            return false;
        }
    }

    float MatrixGraph:: getEdgeWeight(int v1, int v2) {
        if (v1 >= 0 && v1 <= numVertices && v2 >= 0 && v2 <= numVertices) {
            return adjacencyMatrix[v1][v2] == -1? 0 : adjacencyMatrix[v1][v2];
        } else {
            cout << "Invalid vertices.\n";
            return -1; // Indicate error with negative weight
        }
    }

    void MatrixGraph:: setEdgeWeight(int v1, int v2, float weight) {
        if (v1 >= 0 && v1 <= numVertices && v2 >= 0 && v2 <= numVertices) {
            adjacencyMatrix[v1][v2] = weight;
            if (!directed)
               adjacencyMatrix[v2][v1] = weight; // Set weight for reverse edge in undirected graph
        } else {
            cout << "Invalid vertices.\n";
        }
    }

    string MatrixGraph::toString() const {
        stringstream ss;
        for (int i = 1; i <= numVertices; ++i) {
            ss << "[" << std::setw(2) << i << "]:";
            for (int j = 1; j <= numVertices; ++j) {
                if (adjacencyMatrix[i][j] != 0) {
                    float weight = adjacencyMatrix[i][j] == -1? 0 : adjacencyMatrix[i][j];
                    ss << "-->";
                    ss << "[" << std::setw(2) << i << "," << std::setw(2) << j << "::" << std::fixed << std::setprecision(2) << std::setw(6) << weight << "]";
                }
            }

        ss << endl;
    }
            return ss.str();
            }




    void MatrixGraph::printRaw() {
        cout << "Adjacency Matrix:" << endl;
        cout << endl;
        for (int i = 1; i <= numVertices; ++i) {
            for (int j = 1 ; j <= numVertices; ++j) {
                float weight = adjacencyMatrix[i][j] == -1? 0 : adjacencyMatrix[i][j];

            cout << setw(7);
                cout << std::fixed << std::setprecision(2) << weight;

            }
            cout << endl;
        }
    }

    bool MatrixGraph::pathExists(int start, int goal) {
        if (start < 0 || start > numVertices || goal < 0 || goal > numVertices)
            return false;
        bool* visited = new bool[numVertices + 1] {false};
        Queue<int> queue;
        queue.enqueue(start);
        for(int i=0; i<=numVertices; i++) {
            visited[i] = false;
        }
        visited[start] = true;
        while (!queue.isEmpty()) {
            int current = queue.front();
            queue.dequeue();
            if (current == goal) {
                delete[] visited;
                return true;
            }
            for (int i = 1; i <= numVertices; ++i) {
                if (adjacencyMatrix[current][i] != 0 && !visited[i]) {
                    queue.enqueue(i);
                    visited[i] = true;
                }
            }
        }
        delete[] visited;
        return false;
    }

    vector<int> MatrixGraph::getBFSPath(int start, int goal) {
        vector<int> path;
        if (!pathExists(start, goal))
            return path; // If path doesn't exist, return empty path

        bool* visited = new bool[numVertices + 1] {false};
        int* parent = new int[numVertices + 1] {-1}; // To store parent of each node in BFS traversal

        Queue<int> queue;
        queue.enqueue(start);
        for(int i=0; i<=numVertices; i++) {
            parent[i] = -1;
            visited[i] = false;
        }

        visited[start] = true;

        while (!queue.isEmpty()) {
            int current = queue.front();
            queue.dequeue();
            if (current == goal) {
                int p = current;
                while (p != -1) {
                    path.push_back(p);
                    p = parent[p];
                }
                std::reverse(path.begin(), path.end());
                delete[] visited;
                delete[] parent;
                return path;
            }
            for (int i = 1; i <= numVertices; ++i) {
                if (adjacencyMatrix[current][i] != 0 && !visited[i]) {
                    queue.enqueue(i);
                    visited[i] = true;
                    parent[i] = current;
                }
            }
        }
        delete[] visited;
        delete[] parent;
        return path;
    };


std::vector<int> MatrixGraph::getDijkstraPath(int start, int goal) {
    bool* visited = new bool[numVertices + 1] {false};
    int* parent = new int[numVertices + 1] {-1}; // To store parent of each node in BFS traversal
    float* cost = new float[numVertices + 1];

    for(int i=0; i<=numVertices; i++) {
        parent[i] = -1;
        visited[i] = false;
        cost[i] = MAX_INT_D;
    }

    cost[start] = 0;
    visited[start] = true;

    MinHeap<Pair> heap(100);
    std::vector<int> path;
    Pair first; first.weight = 0; first.node = start;
    heap.enqueue(first);

    while(!heap.isEmpty()) {
        Pair node = heap.peek(); heap.dequeue();
        float dis = node.weight;
        int vertx = node.node;
        if(dis > cost[vertx]) {
            continue;
        }

        visited[vertx] = true;
        if(vertx == goal) {
            int p = goal;
            while (p != -1) {
                path.push_back(p);
                p = parent[p];
            }
            std::reverse(path.begin(), path.end());

            delete[] visited;
            delete[] parent;
            delete[] cost;

            return path;

        }

        for(int i=1; i<=numVertices; i++) {
            if (adjacencyMatrix[vertx][i] != 0 && !visited[i]) {
                float newCost = dis + adjacencyMatrix[vertx][i];
                if(newCost < cost[i]) {
                    cost[i] = newCost;
                    parent[i] = vertx;

                    Pair newPair;
                    newPair.node = i;
                    newPair.weight = newCost;

                    heap.enqueue(newPair);
                }
            }
        }
    }

    delete[] visited;
    delete[] parent;
    delete[] cost;

    return path;

}

std::vector<int>* MatrixGraph::getDijkstraAll(int start) {
    bool* visited = new bool[numVertices + 1] {false};
    int* parent = new int[numVertices + 1] {-1}; // To store parent of each node in BFS traversal
    float* cost = new float[numVertices + 1];

    for(int i=0; i<=numVertices; i++) {
        parent[i] = -1;
        visited[i] = false;
        cost[i] = MAX_INT_D;
    }

    cost[start] = 0;
    visited[start] = true;
    std::vector<int>* result = new vector<int>[numVertices];


    MinHeap<Pair> heap(200);
    Pair first; first.weight = 0; first.node = start;
    heap.enqueue(first);

    while(!heap.isEmpty()) {
        Pair node = heap.peek(); heap.dequeue();
        float dis = node.weight;
        int vertx = node.node;
        if(dis > cost[vertx]) {
            continue;
        }

        std::vector<int> path;
        visited[vertx] = true;
        int p = vertx;
        while (p != -1) {
            path.push_back(p);
            p = parent[p];
        }
        std::reverse(path.begin(), path.end());
        result[vertx - 1] = path;



        for(int i=1; i<=numVertices; i++) {
            if (adjacencyMatrix[vertx][i] != 0 && !visited[i]) {
                float newCost = dis + adjacencyMatrix[vertx][i];
                if(newCost < cost[i]) {
                    cost[i] = newCost;
                    parent[i] = vertx;


                    Pair newPair;
                    newPair.node = i;
                    newPair.weight = newCost;

                    heap.enqueue(newPair);
                }
            }
        }
    }

    delete[] visited;
    delete[] parent;
    delete[] cost;

    return result;
}


void MatrixGraph::printPrimMST() {
    int V = numVertices;
    int parent[V + 1];
    int values[V + 1];
    bool visited[V + 1];

    for (int i = 1; i <= V; i++) {
        values[i] = MAX_INT_D;
        visited[i] = false;
    }

    values[1] = 0;
    parent[1] = -1;

    int cnt = 0;
    while(cnt++ < V - 1) {
        int Min = MAX_INT_D, min_index;

        for (int v = 1; v <= V; v++)
            if (visited[v] == false && values[v] < Min)
                Min = values[v], min_index = v;

        int u = min_index;

        visited[u] = true;
        for (int v = 1; v <= V; v++) {

            if (adjacencyMatrix[u][v] != 0 && visited[v] == false && adjacencyMatrix[u][v] < values[v]) {
                parent[v] = u;
                values[v] = adjacencyMatrix[u][v];
            }

        }
    }
    for (int i = 1; i <= numVertices; ++i) {
            cout << "[" << std::setw(2) << i << "]:";
            for (int j = 1; j <= numVertices; ++j) {
                if (adjacencyMatrix[i][j] != 0 && parent[j] == i) {
                    float weight = adjacencyMatrix[i][j] == -1? 0 : adjacencyMatrix[i][j];
                    cout << "-->";
                    cout << "[" << std::setw(2) << i << "," << std::setw(2) << j << "::" << std::fixed << std::setprecision(2) << std::setw(6) << weight << "]";
                }
            }

        cout << endl;
    }
}
