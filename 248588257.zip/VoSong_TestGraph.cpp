/*
Author: Song Vo
Date : 04/18/24
 Description : ...
 */
#include "MatrixGraph_VoSong.h"
#include "Queue_VoSong.hpp"
#include <iostream>
#include <fstream>
#include <iomanip>
#include<cstring>

using namespace std;

void printMenu() {
    cout << "Welcome to the Graph tester!\n"
            "1) Print the graph\n"
            "2) Find a BFS path\n"
            "3) Find a Single Dijkstra Path\n"
            "4) Find all Dijkstra Paths from a start\n"
            "5) Start a file\n"
            "6) Add a BFS path to the file\n"
            "7) Add single Dijkstra Path to file\n"
            "8) Add all Dijkstra Paths from a start\n"
            "0) Quit\n";
}

void printGraph(const MatrixGraph& graph) {
    cout << graph.toString();
}


void findPath(MatrixGraph& graph) {
    int start, goal;
    cin >> start >> goal;

    vector<int> path = graph.getBFSPath(start, goal);

    if (path.empty()) {
        cout << "No BFS path from " << start << " to " << goal << "."<< endl;
    } else {
        cout << "BFS path from " << start << " to " << goal << " is:" << endl;

        int lastVer = -1;
        float weight_total = 0;
        for (int i = 0; i < (int)path.size(); i++) {
            float weight = (lastVer == -1? 0 : graph.getEdgeWeight(lastVer, path[i]));
            weight_total += weight;
            cout << "[" << setw(2) << path[i] << ":" << setw(6) << fixed << setprecision(2) << weight_total << "]";
            if(i != (int)path.size() - 1) {
                cout << "==>";
            }
            lastVer = path[i];
        }
        cout << endl;
    }
}

void startFile(MatrixGraph& graph, ofstream& outputFile) {
    int edge = 0;
    for(int i=1; i<=graph.getNumVertices(); i++) {
        for(int j=1; j<=graph.getNumVertices(); j++){
            if (graph.getEdgeWeight(i, j) != 0){
                edge++;
            }
        }
    }

    outputFile << graph.getNumVertices() << " " << edge << endl;
    for(int i=1; i<=graph.getNumVertices(); i++) {
        for(int j=1; j<=graph.getNumVertices(); j++){
            if (graph.getEdgeWeight(i, j) != 0){
                outputFile << i << " " << j;

                if(graph.getIsWeight()) {
                    outputFile << " " << std::fixed << std::setprecision(6) << graph.getEdgeWeight(i, j);
                }
                outputFile << endl;
            }
        }
    }

}

void addPathToFile(MatrixGraph& graph, ofstream& ofs) {

    int start, goal;
    cin >> start >> goal;

    vector<int> path = graph.getBFSPath(start, goal);

    if (path.empty()) {
        ofs << "No BFS path from " << start << " to " << goal << "."<< endl;
    } else {
        ofs << "BFS path from " << start << " to " << goal << " is:" << endl;
        int lastVer = -1;
        float weight_total = 0;
        for (int i = 0; i < (int)path.size(); i++) {
            float weight = (lastVer == -1? 0 : graph.getEdgeWeight(lastVer, path[i]));
            weight_total += weight;
            ofs << "[" << setw(2) << path[i] << ":" << setw(6) << fixed << setprecision(2) << weight_total << "]";
            if(i != (int)path.size() - 1) {
                ofs << "==>";
            }
            lastVer = path[i];
        }
        ofs << endl;
    }
}


void findDijstrakPath(MatrixGraph& graph) {
    int start, goal;
    cin >> start >> goal;

    vector<int> path = graph.getDijkstraPath(start, goal);

    if (path.empty()) {
        cout << "No DIJKSTRA path from " << start << " to " << goal << "."<< endl;
    } else {
        cout << "DIJKSTRA path from " << start << " to " << goal << " is:" << endl;
        int lastVer = -1;
        float weight_total = 0;
        for (int i = 0; i < (int)path.size(); i++) {
            float weight = (lastVer == -1? 0 : graph.getEdgeWeight(lastVer, path[i]));
            weight_total += weight;
            cout << "[" << setw(2) << path[i] << ":" << setw(6) << fixed << setprecision(2) << weight_total << "]";
            if(i != (int)path.size() - 1) {
                cout << "==>";
            }
            lastVer = path[i];
        }
        cout << endl;
    }
}

void findDijstrakPathExportFile(MatrixGraph& graph, ofstream& ofs) {
    int start, goal;
    cin >> start >> goal;

    vector<int> path = graph.getDijkstraPath(start, goal);

    if (path.empty()) {
        ofs << "No DIJKSTRA path from " << start << " to " << goal << ""<< endl;
    } else {
        ofs << "DIJKSTRA path from " << start << " to " << goal << " is:" << endl;
        int lastVer = -1;
        float weight_total = 0;
        for (int i = 0; i < (int)path.size(); i++) {
            float weight = (lastVer == -1? 0 : graph.getEdgeWeight(lastVer, path[i]));
            weight_total += weight;
            ofs << "[" << setw(2) << path[i] << ":" << setw(6) << fixed << setprecision(2) << weight_total << "]";
            if(i != (int)path.size() - 1) {
                ofs << "==>";
            }
            lastVer = path[i];
        }
        ofs << endl;
    }

}

void findAllDijstrakPath(MatrixGraph& graph) {
    int start;
    cin >> start;

    vector<int>* paths = graph.getDijkstraAll(start);

    for(int i=0; i<graph.getNumVertices(); i++) {
        int vertx = i + 1;
        if(vertx == start) {
            cout << "DIJKSTRA Paths start at Vertex " << vertx << endl;
            continue;
        }
        vector<int> path = paths[i];
        cout << "Path to " << vertx << ": ";
        if (path.empty()) {
            cout << "No DIJKSTRA path from " << start << " to " << i + 1 << ""<< endl;
        } else {
            int lastVer = -1;
            float weight_total = 0;
            for (int i = 0; i < (int)path.size(); i++) {
                float weight = (lastVer == -1? 0 : graph.getEdgeWeight(lastVer, path[i]));
                weight_total += weight;
                cout << "[" << setw(2) << path[i] << ":" << setw(6) << fixed << setprecision(2) << weight_total << "]";
                if(i != (int)path.size() - 1) {
                    cout << "==>";
                }
                lastVer = path[i];
            }
            cout << endl;
        }

    }

     delete[] paths;

}

void findAllDijstrakPathExportFile(MatrixGraph& graph, ofstream& ofs) {
    int start;
    cin >> start;

    vector<int>* paths = graph.getDijkstraAll(start);

    for(int i=0; i<graph.getNumVertices(); i++) {
        int vertx = i + 1;
        if(vertx == start) {
            ofs << "DIJKSTRA Paths start at Vertex " << vertx << endl;
            continue;
        }
        vector<int> path = paths[i];
        ofs << "Path to " << vertx << ": ";
        if (path.empty()) {
            ofs << "No DIJKSTRA path from " << start << " to " << i + 1 << "."<< endl;
        } else {
            int lastVer = -1;
            float weight_total = 0;
            for (int i = 0; i < (int)path.size(); i++) {
                float weight = (lastVer == -1? 0 : graph.getEdgeWeight(lastVer, path[i]));
                weight_total += weight;
                ofs << "[" << setw(2) << path[i] << ":" << setw(6) << fixed << setprecision(2) << weight_total << "]";
                if(i != (int)path.size() - 1) {
                    ofs << "==>";
                }
                lastVer = path[i];
            }
            ofs << endl;
        }

    }

    delete[] paths;

}

int main(int argc, char *argv[]) {
    bool isDirected = true;
    bool isWeight = true;

    // Assuming graph edges are added here
    if(argc == 4 && strcmp(argv[3], "-ud") == 0) {
        isDirected = false;
    }

    if(strcmp(argv[1], "-u") == 0) {
        isWeight = false;
    }

     // Assuming 8 vertices and directed graph

    int n, edge;
    ifstream ifs(argv[2]);
    ifs >> n >> edge;
    MatrixGraph graph(n, isDirected);
    graph.setIsWeight(isWeight);
    for(int i=0; i<edge; i++) {
        int u, v;
        float w;
        ifs >> u >> v;
  //      cout << u << " " << v << endl;
        if(isWeight) {
            ifs >> w;
            graph.addEdge(u, v, w);
        } else {
            graph.addEdge(u, v, 1);
        }
    }
    ifs.close();

    string filename;

    ofstream outputFile;
    int choice;
    do {
        printMenu();

        cin >> choice;

        switch (choice) {
            case 1:
                printGraph(graph);
                break;
            case 2:
                findPath(graph);
                break;
            case 3:
                findDijstrakPath(graph);
                break;
            case 4:
                findAllDijstrakPath(graph);
                break;
            case 5:
                cin >> filename;
                outputFile.open(filename);
                if(outputFile.is_open()) {
                    startFile(graph, outputFile);
                }
                break;
            case 6:
                if(!outputFile.is_open()) {
                    cout << "No file has been created yet." << endl;
                } else {
                    addPathToFile(graph, outputFile);
                }
                break;
            case 7:
                if(!outputFile.is_open()) {
                    cout << "No file has been created yet." << endl;
                } else {
                    findDijstrakPathExportFile(graph, outputFile);
                }
                break;
            case 8:
                if(!outputFile.is_open()) {
                    cout << "No file has been created yet." << endl;
                } else {
                    findAllDijstrakPathExportFile(graph, outputFile);
                }
                break;
            case 9999:
                graph.printRaw();
                break;
            case 1111:
                graph.printPrimMST();
                break;
            case 0:
                outputFile.close();
                return 0;
            default:
                cout << "Invalid choice. Please try again.\n";
        }
    } while (choice != 0);

    return 0;
}
