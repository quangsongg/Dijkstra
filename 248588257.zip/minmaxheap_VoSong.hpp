#ifndef MINMAXHEAP_VOSONG_HPP
#define MINMAXHEAP_VOSONG_HPP

#include <stdexcept>
/*
Author: Song Vo
Date : 3/14/24
 Description : creating a min/max heap to do basic tasks such as add new nodes in, delete a nodes, peek and see if size is empty,...
 */
//here i created 2 seperated class which are min/max heap. Even though some of the method such as peek, getSize(),... are fairly similar but the Heapify up and down are quiet different. Heapify up are being used to re-organizes the tree and enqueueing a new element and heapify down on the other hand is to rearanging nodes to it's correct position after dequeue a node.
//
template<typename T>
class MinHeap {
private:
    T* heapArray;
    int capacity;
    int size;

public:
    MinHeap() : capacity(10), size(0) {
        heapArray = new T[capacity];
    }

    MinHeap(int size) : capacity(size), size(0) {
        heapArray = new T[capacity];
    }

    ~MinHeap() {
        delete[] heapArray;
    }

    void enqueue(T item) {
        if (size >= capacity) {
            throw std::runtime_error("MinHeap is full");
        }

        heapArray[size] = item;
        heapifyUp(size);
        size++;
    }

    void dequeue() {
        if (isEmpty()) {
            throw std::runtime_error("MinHeap is empty"); //check if empty
        }

        heapArray[0] = heapArray[size - 1]; //making the 1st element to be last to dequeue it
        size--;//decrease size
        heapifyDown(0);
    }

    T peek() const {
        if (isEmpty()) {
            throw std::runtime_error("MinHeap is empty");
        }

        return heapArray[0];
    }

    int getSize() const {
        return size;
    }

    int getCapacity() const {
        return capacity;
    }

    bool isEmpty() const {
        return size == 0;
    }

private:
    void heapifyUp(int index) {
        int parent = (index - 1) / 2;

        while (index > 0 && heapArray[index] < heapArray[parent]) {
            std::swap(heapArray[index], heapArray[parent]);
            index = parent;
            parent = (index - 1) / 2;
        }
    }

    void heapifyDown(int index) {
        int leftChild = 2 * index + 1;
        int rightChild = 2 * index + 2;
        int smallest = index;

        if (leftChild < size && heapArray[leftChild] < heapArray[smallest]) {
            smallest = leftChild;
        }

        if (rightChild < size && heapArray[rightChild] < heapArray[smallest]) {
            smallest = rightChild;
        }

        if (smallest != index) {
            std::swap(heapArray[index], heapArray[smallest]);
            heapifyDown(smallest);
        }
    }
};

template<typename T>
class MaxHeap {
private:
    T* heapArray;
    int capacity;
    int size;

public:
    MaxHeap() : capacity(10), size(0) {
        heapArray = new T[capacity];
    }

    MaxHeap(int size) : capacity(size), size(0) {
        heapArray = new T[capacity];
    }

    ~MaxHeap() {
        delete[] heapArray;
    }

    void enqueue(T item) {
        if (size >= capacity) {
            throw std::runtime_error("MaxHeap is full");
        }

        heapArray[size] = item;
        heapifyUp(size);
        size++;
    }

    void dequeue() {
        if (isEmpty()) {
            throw std::runtime_error("MaxHeap is empty");
        }

        heapArray[0] = heapArray[size - 1];
        size--;
        heapifyDown(0);
    }

    T peek() const {
        if (isEmpty()) {
            throw std::runtime_error("MaxHeap is empty");
        }

        return heapArray[0];
    }

    int getSize() const {
        return size;
    }

    int getCapacity() const {
        return capacity;
    }

    bool isEmpty() const {
        return size == 0;
    }

private:
    void heapifyUp(int index) {
        int parent = (index - 1) / 2;

        while (index > 0 && heapArray[index] > heapArray[parent]) {
            std::swap(heapArray[index], heapArray[parent]);
            index = parent;
            parent = (index - 1) / 2;
        }
    }

    void heapifyDown(int index) {
        int leftChild = 2 * index + 1;
        int rightChild = 2 * index + 2;
        int largest = index;

        if (leftChild < size && heapArray[leftChild] > heapArray[largest]) {
            largest = leftChild;
        }

        if (rightChild < size && heapArray[rightChild] > heapArray[largest]) {
            largest = rightChild;
        }

        if (largest != index) {
            std::swap(heapArray[index], heapArray[largest]);
            heapifyDown(largest);
        }
    }
};

#endif //MINMAXHEAP_VOSONG_HPP
