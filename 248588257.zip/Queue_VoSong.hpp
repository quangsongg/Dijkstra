#ifndef QUEUE_HPP
#define QUEUE_HPP

#include <iostream>
#include <stdexcept>

template<typename T>
class Queue {
private:
    struct Node {
        T data;
        Node* next;
        Node(const T& data) : data(data), next(nullptr) {}
    };

    Node* frontPtr;
    Node* rearPtr;
    size_t size;

public:
    Queue() : frontPtr(nullptr), rearPtr(nullptr), size(0) {}

    ~Queue() {
        while (!isEmpty())
            dequeue();
    }

    void enqueue(const T& data) {
        Node* newNode = new Node(data);
        if (isEmpty()) {
            frontPtr = newNode;
        } else {
            rearPtr->next = newNode;
        }
        rearPtr = newNode;
        size++;
    }

    void dequeue() {
        if (isEmpty())
            throw std::runtime_error("Queue is empty");
        Node* temp = frontPtr;
        frontPtr = frontPtr->next;
        delete temp;
        size--;
        if (isEmpty())
            rearPtr = nullptr;
    }

    T& front() const {
        if (isEmpty())
            throw std::runtime_error("Queue is empty");
        return frontPtr->data;
    }

    bool isEmpty() const {
        return size == 0;
    }

    size_t getSize() const {
        return size;
    }
};

#endif // QUEUE_HPP
